=== VITIM Connector ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.7.0
License: GPLv2 or later

Conectează site-ul la panoul VITIM.

== Description ==
* Trimite la fiecare oră starea site-ului: versiunea WordPress și PHP, tema, pluginurile cu actualizări în așteptare.
* Actualizările de pluginuri, teme și WordPress apar automat în jurnalul de lucrări VITIM, vizibil clientului.
* Afișează formularele de abonare publicate în panoul VITIM (popup, flyout, bară, în pagină).
* WooCommerce: trimite produsele văzute, coșurile, comenzile începute și plasate, catalogul de produse; linkul din emailul de coș abandonat reface coșul.
* Bannerul de cookie-uri VITIM (setat din panou): Google Consent Mode v2 în <head>, shortcode [vitim_cookies] pentru politica de cookie-uri, urmărirea din magazin doar cu acord de marketing.
* Vizibilitate în asistenții AI (la cerere din panou): /llms.txt cu rezumatul firmei și date structurate complete (zonă deservită, profiluri oficiale).
* Comunicarea e semnată (HMAC-SHA256); pluginul nu primește comenzi de la distanță.

== Installation ==
1. Module → Adaugă nou → Încarcă modul → vitim-connector.zip → Activează.
2. Setări → VITIM → lipește codul de conectare primit de la VITIM → Conectează.
