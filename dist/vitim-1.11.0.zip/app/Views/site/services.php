<?php
use App\Core\View;

echo View::partial('site/partials/page_hero', [
    'crumbs' => [['Servicii', '/servicii']],
    'eyebrow' => icon('layers') . ' ' . count(\App\Core\Site::services()) . ' servicii, un singur partener',
    'title' => 'Servicii IT, securitate, automatizări AI și creștere digitală pentru firme',
    'lead' => 'Toate serviciile departamentului tău extern de IT & AI. Le poți lua separat sau împreună, într-un abonament pentru companii de la ' . setting('pricing_from', '1.000') . ' RON/lună.',
    'actions' => '<a class="btn btn-primary btn-lg" href="' . e(url('/contact')) . '">Solicită o evaluare ' . icon('arrow-right', 'ico ico-move') . '</a> <a class="btn btn-ghost btn-lg" href="' . e(url('/#abonamente')) . '">Vezi abonamentele</a>',
]);
?>
<section class="section">
  <div class="container">
    <?php foreach ($groups as $key => $g): if (!empty($g['cat']['secondary'])) { continue; } ?>
    <div class="svc-group" id="<?= e($key) ?>">
      <div class="svc-group-head" data-reveal>
        <div style="max-width:640px">
          <span class="eyebrow"><?= e($g['cat']['short']) ?></span>
          <h2 style="margin-bottom:10px"><?= e($g['cat']['name']) ?></h2>
          <p class="muted" style="margin:0"><?= e($g['cat']['intro']) ?></p>
        </div>
      </div>
      <div class="grid-3">
        <?php foreach ($g['items'] as $i => $s): ?>
        <article class="card" data-reveal data-delay="<?= ($i % 3) * 70 ?>">
          <?php if (!empty($s['image'])): ?><div class="card-img"><img src="<?= e(upload_url($s['image'])) ?>" srcset="<?= e(\App\Core\Uploader::srcset($s['image'])) ?>" sizes="(max-width:720px) 100vw, 400px" alt="" loading="lazy" width="960" height="540"></div><?php endif; ?>
          <div class="icon-tile"><?= icon($s['icon'] ?: 'sparkles') ?></div>
          <h3><?= e($s['title']) ?></h3>
          <p><?= e($s['excerpt']) ?></p>
          <span class="more">Află mai mult <?= icon('arrow-up-right') ?></span>
          <a class="card-link" href="<?= e(url('/servicii/' . $s['slug'])) ?>" aria-label="<?= e($s['title']) ?>"></a>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (!empty($groups['service'])): $g = $groups['service']; ?>
    <div class="svc-minor" id="service" data-reveal>
      <div><span class="eyebrow"><?= e($g['cat']['short']) ?></span><h2><?= e($g['cat']['name']) ?></h2><p class="muted"><?= e($g['cat']['intro']) ?></p></div>
      <ul><?php foreach ($g['items'] as $s): ?><li><a href="<?= e(url('/servicii/' . $s['slug'])) ?>"><?= icon($s['icon'] ?: 'wrench') ?><span><strong><?= e($s['title']) ?></strong><small><?= e($s['tagline']) ?></small></span><?= icon('arrow-up-right') ?></a></li><?php endforeach; ?></ul>
    </div>
    <?php endif; ?>
  </div>
</section>
<section class="section" style="padding-top:0">
  <div class="container"><?= View::partial('site/partials/cta_form', ['title' => 'Nu știi de unde să începi?', 'text' => 'Descrie-ne pe scurt situația. Îți recomandăm gratuit soluția potrivită și îți spunem sincer ce merită și ce nu.']) ?></div>
</section>
